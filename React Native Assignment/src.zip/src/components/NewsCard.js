import React from "react";
import { View, StyleSheet, Text, TouchableOpacity, Button } from "react-native";

export default function NewsCard({ data, deleteAction }) {
  return (
    <View style={styles.card}>
      <View style={styles.textCont}>
        <Text style={styles.title}>Title-{data.title}</Text>
        <Text style={styles.subTitle}>Description-{data.description}</Text>
        
        <TouchableOpacity style={styles.button}>
          <Button
            color="#c90086"
            onPress={() => deleteAction(data)}
            title="Delete"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 15,
    backgroundColor: "gray",
    marginBottom: 20,
    overflow: "hidden",
  },
  button: {
    marginLeft: "auto",
    marginRight: 0,
  },
  date: {
    color: "#c90086",
    marginVertical: 5,
    fontWeight: "bold",
  },
  img: {
    width: "100%",
    height: 200,
  },
  subTitle: {
    color: "#00b5a6",
    fontWeight: "bold",
  },
  textCont: {
    padding: 20,
  },
  title: {
    marginBottom: 8,
  },
});
