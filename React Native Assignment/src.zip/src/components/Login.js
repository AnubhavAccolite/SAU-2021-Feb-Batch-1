
import React, { useState, useEffect } from "react";
import {
  Text,
  TextInput,
  View,
  StyleSheet,
  Button,
  AsyncStorage,
} from "react-native";

const Login = ({ navigation }) => {
  const [username, setUserName] = useState("");
  const [Password, setPassword] = useState("");
  useEffect(() => {
    checkAuth();
  });
  const checkAuth = async () => {
    const userName = await AsyncStorage.getItem("username1");
    let data = JSON.parse(userName);
    if (data && data.username) {
      navigation.navigate("All Notes");
    }
    return;
  };
  const login = async () => {
    let data = await AsyncStorage.getItem("username1");
    data = JSON.parse(data);
    if (data)
      await AsyncStorage.setItem(
        "username1",
        JSON.stringify({ username: username, data: data.data })
      );
    else
      await AsyncStorage.setItem(
        "username1",
        JSON.stringify({ username: username, data: [] })
      );
    navigation.navigate("All Notes");
  };
  return (
    <View style={Styles.container}>
      <Text style={Styles.loginTextStyle}>Login Details</Text>
      <TextInput
        style={Styles.textInputStyle}
        onChangeText={(text) => setUserName(text)}
        placeholder="Enter username"
      />
      <TextInput
        secureTextEntry={true}
        style={Styles.textInputStyle}
        onChangeText={(text) => setPassword(text)}
        placeholder="Enter password"
      />
      <Button title="Login" onPress={login} />
    </View>
  );
};

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor:"gray",
  },
  loginTextStyle: {
    fontSize: 45,
    fontWeight: "700",
    marginVertical: 20,
    color:"blue",
  },
  textInputStyle: {
    borderColor: "blue",
    borderWidth: 1,
    borderRadius: 5,
    fontSize: 20,
    padding: 5,
    width: "90%",
    marginBottom: 20,
  },
});

export default Login;
